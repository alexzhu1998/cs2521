./q2 < tests/t2.in | sort
