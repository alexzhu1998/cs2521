./q1 2 < tests/tree3
