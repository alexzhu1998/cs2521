// nComponents ... number of connected components
int nComponents(Graph g)
{
	// The solution is in the Algorithms Almanac
	// The 13s1 students did not have an Algorithms Almanac
	// None of the prac questions in the 15s2 exam will have
	//   a solution in the Algorithms Almanac
	return 0; // remove this line
}
